function Cmt=ranqimodel(P)  %????P?KWh????????????????,?????
Qdw=35880;       %calorific value-KJ/m3?
eta1=0.7088;    %efficiency
%P=Q/1.36;   %   1.36-heat-to power ratio
Q=1.36*P;      %heat
F=(P+Q)/(eta1*Qdw); %F-comsumed fuel amount
Cmt=F*0.5;          %0.5-fuel price
end
